//
//  NativeVideoListViewController.h
//  ApplinsSDK_iOS
//
//  Created by 兰旭平 on 2018/8/30.
//  Copyright © 2018年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NativeVideoListViewController : UIViewController

@end
