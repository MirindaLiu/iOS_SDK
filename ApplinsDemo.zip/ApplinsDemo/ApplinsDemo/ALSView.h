

#import <ApplinsSDK/Applins.h>
@interface ALSView : ALSNativeAd
@property (nonatomic, strong)UIImageView *logoImage;
@property (nonatomic, strong)UILabel *titleLable;
@property (nonatomic, strong)UIImageView *iconImage;
@property (nonatomic, strong)UIImageView *imageImage;
@property (nonatomic, strong)UILabel *descLable;
@property (nonatomic, strong)UIButton *button;
@property (nonatomic, strong)UILabel *starLable;

- (void)setValuesWith:(ALSNativeAdModel *)model;
@end
