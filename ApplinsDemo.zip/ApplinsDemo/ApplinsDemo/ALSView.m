

#import "ALSView.h"
@implementation ALSView
- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self layoutViewsWithFrame:frame];
    }
    return self;
}
- (void)layoutViewsWithFrame:(CGRect)frame {
    self.backgroundColor = [UIColor whiteColor];
    self.button = [UIButton buttonWithType:UIButtonTypeCustom];
    self.imageImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.width / 1.9)];
    self.logoImage = [[UIImageView alloc]initWithFrame:CGRectMake(frame.size.width - 16, 0, 16, 16)];//广告标识
    self.iconImage = [[UIImageView alloc]initWithFrame:CGRectMake(7, frame.size.width / 1.9 - 23, 40, 40)];//icon
    self.iconImage.layer.cornerRadius = 6.5;
    [self.iconImage.layer setMasksToBounds:YES];
    self.titleLable = [[UILabel alloc]initWithFrame:CGRectMake(55, frame.size.width / 1.9 - 20, frame.size.width-200, 20)];//标题
    self.titleLable.font = [UIFont systemFontOfSize:14];
    self.titleLable.textColor = [UIColor whiteColor];
    self.button.frame = CGRectMake(frame.size.width-60, frame.size.width / 1.9 - 23, 60, 20);
    self.button.titleLabel.font = [UIFont systemFontOfSize:14];
    self.descLable = [[UILabel alloc]initWithFrame:CGRectMake(55, frame.size.width / 1.9 - 3 , frame.size.width - 55, 20)];
    self.descLable.textColor = [UIColor blackColor];
    self.descLable.font = [UIFont systemFontOfSize:14];
    [self.button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [self addSubview:self.imageImage];
    UIView *back = [[UIView alloc]initWithFrame:CGRectMake(0, frame.size.width / 1.9 - 23, frame.size.width, 43)];
    back.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];;
    [self addSubview:back];
    [self addSubview:self.logoImage];
    [self addSubview:self.titleLable];
    [self addSubview:self.iconImage];
    [self addSubview:self.descLable];
    [self addSubview:self.button];
}
- (void)setValuesWith:(ALSNativeAdModel *)model {
    self.adNativeModel = model;
    self.titleLable.text = model.title;
    [self getImageFromURL:model.icon img:^(UIImage *ig) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.iconImage.image = ig;
        });
    }];
    [self getImageFromURL:model.image img:^(UIImage *ig) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageImage.image = ig;
        });
    }];
    self.descLable.text = model.desc;
    [self.button setTitle:model.button forState:UIControlStateNormal];
    self.starLable.text = [NSString stringWithFormat:@"%f",model.star];
    self.logoImage.image = model.ADsignImage;
}
- (void)getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}
@end
