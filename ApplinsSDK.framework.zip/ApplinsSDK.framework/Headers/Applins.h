//
//  Applins.h
//  ApplinsSDK
//
//  Created by Mirinda on 16/7/27.
//  Copyright © 2016年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import <ApplinsSDK/ApplinsSDK.h">
#import <ApplinsSDK/ApplinsSDK.h>
#import <ApplinsSDK/ALSADExternalDelegate.h>
#import <ApplinsSDK/ALSElementModel.h>
#import <ApplinsSDK/ALSNativeAd.h>
#import <ApplinsSDK/ALSNativeModelDelegate.h>
#import <ApplinsSDK/ALSRewardVideoDelegate.h>
#import <ApplinsSDK/ALSNativeVideoModel.h>
#import <ApplinsSDK/ALSNativeVideoDelegate.h>
#import <ApplinsSDK/ALSVideoViewController.h>
#import <ApplinsSDK/ALSMediaView.h>
#import <ApplinsSDK/ALSADMRAIDVIew.h>

//! Project version number for ApplinsSDK.
FOUNDATION_EXPORT double APPLINSSDK_VERSIONNumber;
//! Project version string for ApplinsSDK.
FOUNDATION_EXPORT const unsigned char APPLINSSDK_VERSIONString[];

// In this header, you should import all the public headers of your framework using statements like #import <ApplinsSDK/PublicHeader.h>
